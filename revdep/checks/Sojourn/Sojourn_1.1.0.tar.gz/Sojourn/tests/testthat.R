library(testthat)
library(Sojourn)

test_check("Sojourn")
