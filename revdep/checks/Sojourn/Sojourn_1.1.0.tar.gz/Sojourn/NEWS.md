# Sojourn 1.1.0

* Removed dependencies on Sojourn.Data and Rcpp
* Fixed all CRAN check errors

# Sojourn 1.0.2

* Fixed an invalid URL that was not caught in 1.0.1

# Sojourn 1.0.1

* Fixed invalid URLs

# Sojourn 1.0.0

* Added a transition indicator to the youth Sojourn models
* Fixed bugs in original triaxial method (see #2)

# Sojourn 0.1.0

* Initial submission of the `Sojourn` package.
